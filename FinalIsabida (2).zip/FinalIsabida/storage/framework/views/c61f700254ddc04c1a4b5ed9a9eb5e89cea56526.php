<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/settings.css')); ?>">
</head>
<body>
    

    <div class="setings-con">
        <div class="set">
            
            <a href="<?php echo e(route('admin-adminHome')); ?>" class="btn btn-primary btn-sm mb-4"><i class="fa-solid fa-backward"></i></a>
            
            <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
            <form action="<?php echo e(route('admin-newPass')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="single-box">
                    <label for="">Username</label><br>
                    <input type="text" value="<?php echo e($users->username); ?>"  name="username">
                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                </div>

                <div class="single-box">
                    <label for="">New Password</label><br>
                    <input style="text-transform: uppercase;" type="password" name="password" value="<?php echo e(old('password')); ?>">
                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                </div>

                <div class="single-box">
                    <label for="">Repeat Password</label><br>
                    <input style="text-transform: uppercase;" type="password" name="repeatPassword" value="<?php echo e(old('repeatPassword')); ?>">
                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['repeatPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                </div>
                
                <button style="float: right;" type="submit" class="btn btn-success btn-sm">Save</button>
            </form>
           <div class="newmail">
                <form action="<?php echo e(route('admin-saveEmail')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="single-box mt-4">
                        <label for="">Email</label><br>
                        <input type="email" value="<?php echo e($contact->gmail); ?>"  name="email">
                        <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                    </div>
                    
                    <button style="float: right;" type="submit" class="btn btn-success btn-sm">Save</button>
                </form>
           </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/admin/admin-settings.blade.php ENDPATH**/ ?>