<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Strand</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/adminhome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/strand.css')); ?>">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
</head>
<body>
    

    <div class="admin-header">
            <div class="admin-header-right">
                <a href="<?php echo e(route('logout')); ?>" type="submit" class="btn btn-danger btn-sm mt-3"> <i class="fa-solid fa-right-from-bracket"></i> </a>
                    
            </div>
            <div class="menuAdmin">
                <li><a href="<?php echo e(route('admin-adminHome')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('admin-adminUser')); ?>">Users</a></li>
                <li><a style="color: green;" href="<?php echo e(route('admin-adminStrand')); ?>">Strand</a></li>
                <li><a href="<?php echo e(route('admin-profile')); ?>">Profile</a></li>
                <li><a href="<?php echo e(route('admin-adminSettings')); ?>">Settings</a></li>
                <li><a href="<?php echo e(route('admin-question')); ?>"><span>Reports</span></a></li>
            </div>
        </div>

    <div class="strand">
        <div class="sbg">

        </div>
        <div class="strandContainer">
            <div class="strandBox">
                
                <!-- <a href="<?php echo e(route('admin-adminHome')); ?>" class="btn btn-primary btn-sm mt-2">Main Dashboard </a> -->
                <p class="p1 mt-3 mb-3">*Create Strand Here</p>
                
                <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
                <form action="<?php echo e(route('admin-addStrand')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="">Acronym</label>
                    <input style="text-transform: uppercase;" type="text" name="acronym">
                    
                    <p style="color: red" ><?php $__errorArgs = ['acronym'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                    <label for="">Strand Name</label>
                    <input style="text-transform: uppercase;" type="text" name="strand">
                    
                    <p style="color: red" ><?php $__errorArgs = ['strand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                    <button type="submit" class="btn btn-success btn-sm mt-2">Create Save</button>
                </form>
            </div>
            <div class="strandBox2">
                                
                <?php if(session('updated')): ?><div class="alert alert-success"><?php echo e(session('updated')); ?></div><?php endif; ?>


                <table id="example" class="table table-striped mt-2" style="width:100%">
                    <thead>
                        <tr>
                            <th>Acronym</th>
                            <th>Strand Name</th>
                            <th>Operation</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $strands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($strand->acronym); ?></td>
                            <td><?php echo e($strand->strand); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin-deleteStrand', ['id' => $strand->id])); ?>" class="btn btn-danger btn-sm mt-2">Delete</a>
                                <a href="<?php echo e(route('admin-UpdateStrandView', ['id' => $strand->id])); ?>" class="btn btn-primary btn-sm mt-2">Update</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Acronym</th>
                            <th>Strand Name</th>
                            <th>Operation</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    
    <script>
        new DataTable('#example');
    </script>


</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/admin/admin-adminStrand.blade.php ENDPATH**/ ?>