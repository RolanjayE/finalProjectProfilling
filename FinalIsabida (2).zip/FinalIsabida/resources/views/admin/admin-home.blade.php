<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/adminhome.css') }}">
   
</head>
<body>


    <div class="admin-home">
        <div class="admin-header">
            <div class="admin-header-right">
                <a href="{{ route('logout') }}" type="submit" class="btn btn-danger btn-sm mt-3"> <i class="fa-solid fa-right-from-bracket"></i> </a>
                    
            </div>
            <div class="menuAdmin">
                <li><a style="color: green;" href="{{ route('admin-adminHome') }}">Dashboard</a></li>
                <li><a href="{{ route('admin-adminUser') }}">Users</a></li>
                <li><a href="{{ route('admin-adminStrand') }}">Strand</a></li>
                <li><a href="{{ route('admin-profile') }}">Profile</a></li>
                <li><a href="{{ route('admin-adminSettings') }}">Settings</a></li>
                <li><a href="{{ route('admin-question') }}"><span>Reports</span></a></li>
            </div>
        </div>


        <div class="admin-mian">
            <div class="backImg">
                <img class="img6" src="{{ asset('image/grad2.jpg') }}" alt="">
            </div>
            <div class="wrapper2 adminMainContainer">
                <div class="adminLeft">
                @foreach ($strandCounts as $strandCount)
                    @if($strandCount->strand != 'TEMP')
                        <div class="adminLeftBox">
                            <a href="{{ route('admin-strandProfiles', ['id' => $strandCount->id ]) }}">{{ $strandCount->strand  }}</a><br>
                            <i class="fa-solid fa-user mt-2"></i> <span>{{ $strandCount->user_count }}</span>
                        </div>
                    @endif
                @endforeach
                </div>
                <div class="admin-right">

                    <div class="box-content">

                    @foreach ($profiles as $profile)
                        <div class="cBox">
                            <div class="img">
                            @if($profile->profile != "")
                                <img id="profileImage" class="img5 mb-3" src="{{ asset('storage/photos/' . $profile->profile) }}" alt="Profile Photo">
                            @else
                                <img class="img5 mb-2" id="profileImage" src="{{ asset('image/profile.png') }}" alt="">
                            @endif
                            </div>
                            <div class="info">
                                <p class="p5 mt-3">{{ $profile->firstname }} {{ $profile->lastname }}</p>
                            </div>
                        </div> 
                    @endforeach
                    
                    
                        
                        
                    </div>
                    
                    <a href="{{ route('admin-profile') }}" style="float: right; width: 100%;" type="submit" class="btn btn-success btn-sm mt-3">Visit Profiles </a>
                    
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>