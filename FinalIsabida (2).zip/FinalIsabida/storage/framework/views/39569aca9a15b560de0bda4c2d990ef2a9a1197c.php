<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/question.css')); ?>">
</head>
<body>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Go college || Stop College', 'Percentage'],
          
          <?php $__currentLoopData = $countYesCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            ["<?php echo e($course->course); ?>", <?php echo e($course->count); ?>],
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        var options = {
          title: 'Report Grapth',
          width: 900,
          legend: { position: 'none' },
          chart: { title: 'Report Grapth',
                   subtitle: 'alumni by percentage' },
          bars: 'horizontal', // Required for Material Bar Charts.
          axes: {
            x: {
              0: { side: 'top', label: 'Percentage'} // Top x-axis.
            }
          },
          bar: { groupWidth: "90%" }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        chart.draw(data, options);
      };
    </script>








    <div class="question isabidaCute">  

    
        <div class="bgq">

        </div>
        

        <div class="questionWrapper">
            
            <div class="head-q">
                <a href="<?php echo e(route('admin-adminHome')); ?>" class="btn btn-primary btn-sm mt-2"><i class="fa-solid fa-house"></i> Main Dashboard </a>
                <a href="<?php echo e(route('admin-question')); ?>" class="btn btn-success btn-sm mt-2"><i class="fa-solid fa-table"></i> Back to table </a>
          </div>
       
            <div style="padding: 4rem;" class="ggGrapth">
                <div id="top_x_div" style="width: 900px; height: 400px;"></div>
            </div>
            
        </div>


    </div>
    
</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/admin/admin-reportView3.blade.php ENDPATH**/ ?>