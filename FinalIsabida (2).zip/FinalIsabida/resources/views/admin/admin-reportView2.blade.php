<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/question.css') }}">
</head>
<body>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['WorkNumber of students enrolled in GCC',     {{ $enrolledCount }}],
          ['Number of students who didnt enroll in GCC',      {{ $notEnrolledCount }}]
        ]);

        var options = {
          title: 'My Daily Activities',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>


    <div class="question isabidaCute">  

    
        <div class="bgq">

        </div>
        

        <div class="questionWrapper">
            
            <div class="head-q">
                <a href="{{ route('admin-adminHome') }}" class="btn btn-primary btn-sm mt-2"><i class="fa-solid fa-house"></i> Main Dashboard </a>
                <a href="{{ route('admin-question') }}" class="btn btn-success btn-sm mt-2"><i class="fa-solid fa-table"></i> Back to table </a>
            </div>

            <p class="p1">SENIOR HIGH SCHOOL GRADUATES, COLLEGES ENROLLMENT STATUS</p>

            <p class="p">This grapth summarizes GCC enrollment with <span>{{ $enrolledCount }} </span>students enrolled and <span>{{ $notEnrolledCount }} </span> students not enrolled</p>
              

            <div style="padding: 4rem; 3rem" class="ggGrapth">
                <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
            </div>
        </div>


    </div>
    
</body>
</html>