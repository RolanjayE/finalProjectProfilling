<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ask;
use App\Models\strand;
use App\Models\contact;
use App\Models\profile;
use App\Models\background;
use App\Models\users;
use App\Models\course;
use Illuminate\Validation\Rule;
use Hash;
use DB;


class user extends Controller
{
    
    public function userHome() {
        $ask = ask::where('userId', session('users')->id)->first();
        $contact = contact::where('userId', session('users')->id)->first();
        $strands = strand::where('status', 0)->get();
        $userStrand = strand::where('id',$ask->strand)->first();
        $background = background::where('userId', session('users')->id)->first();
        $users = users::where('id', session('users')->id)->first();

        if($ask) {
            $profiles = profile::where('userId', session('users')->id)->first();
            return view('user/user-home', compact('profiles', 'contact', 'ask', 'strands', 'userStrand', 'background', 'users'));
        } else {
            return view('user/user-usertAlertOne');
        }

    }

    public function userHomeMain() {
        $ask = ask::where('userId', session('users')->id)->first();
        if($ask) {

            $profiles = profile::where('userId', session('users')->id)->first();
            $ask = ask::where('userId', session('users')->id)->first();
            $strand = strand::where('id', $ask->strand)->first();

            $profileSpecials = DB::table('profiles')
            ->join('asks', 'profiles.userId', '=', 'asks.userId')
            ->join('strands', 'asks.strand', '=', 'strands.id')
            ->where('strands.strand', $strand->strand)
            ->select('profiles.*')
            ->get();
    
            return view('user/user-userHomeMain', compact('profiles', 'strand', 'ask', 'profileSpecials'));
        } else {
            return view('user/user-usertAlertOne');
        }
    }

    public function usertAlertOne() {
        $ask = ask::where('userId', session('users')->id)->first();
        if ($ask) {
            $strands = strand::where('status', 0)->get();
            return view('user/user-usertAlertThree', compact('strands'));
        } else {
            return view('user/user-usertAlertOne');
        }
    }

    public function usertAlertTwo() {
        $ask = ask::where('userId', session('users')->id)->first();
        if($ask) {
            return view('user/user-usertAlertTwo');
        } else {
            return view('user/user-usertAlertOne');
        }
    }

    public function usertAlertThree() {
        $strands = strand::where('status', 0)->get();
        return view('user/user-usertAlertThree', compact('strands'));
    }

    public function usertAlertFour() {
        
        $asks = ask::where('userId', session('users')->id)->first();
        // dd($asks);
        if($asks->proceed == 'yes') {
            return view('user/user-usertAlertFour', compact('asks'));
        } else {
            return redirect()->route('user-userHomeMain');
        }
       

    }


    public function userAgree (Request $request) {
        $request->validate([
            'agree' => 'required',
        ]);

        $asks = ask::where('userId', session('users')->id)->first();
        if ($asks) {
            $asks->agree = $request->agree;
            $asks->save();
            return redirect()->route('user-usertAlertThree');

        } 
        
        $ask = new ask();
        $ask->strand = 3;
        $ask->year = "";
        $ask->proceed = "";
        $ask->collegeName = "";
        $ask->related = "";
        $ask->agree = $request->agree;
        $ask->userId = session('users')->id;
        $ask->status = 0;
        $ask->save();
        return redirect()->route('user-usertAlertThree');

    }

    public function userAsk (Request $request) {
        $request->validate([
            'strand' => 'required',
            'year' => 'required',
            'proceed' => 'required',
        ]);

      

        $ask = ask::where('userId', session('users')->id)->first();
        $ask->strand = $request->strand;
        $ask->year = $request->year;
        $ask->proceed = $request->proceed;

        if($request->proceed == "no") {
            $ask->collegeName = "";
            $ask->related = "";
        } else {
            if (is_null($request->collegeName)) {
               
                $ask->collegeName = "yes";
                $ask->related = $request->related;
            } else {
                $ask->collegeName = $request->collegeName;
                $ask->related = $request->related;
            }
        }

        $ask->save();
        return redirect()->route('user-usertAlertTwo');

    }

    public function userProfile (Request $request) {

        $profiles = profile::where('userId', session('users')->id)->first();

        if($profiles) {
            $profiles->profile    = "";
            $profiles->firstname  = $request->firstname;
            $profiles->middlename = $request->middlename;
            $profiles->lastname   = $request->lastname;
            $profiles->birth      = $request->birth;
            $profiles->gender     = $request->gender;
            $profiles->selfStatus = $request->selfStatus;
            $profiles->save();
            return redirect()->route('user-userHomeMain');
        }
       
        $profile = new profile();
        $profile->profile    = "";
        $profile->firstname  = $request->firstname;
        $profile->middlename = $request->middlename;
        $profile->lastname   = $request->lastname;
        $profile->birth      = $request->birth;
        $profile->gender     = $request->gender;
        $profile->selfStatus = $request->selfStatus;
        $profile->userId = session('users')->id;
        $profile->save();

        $contact = new contact();
        $contact->gmail = "";
        $contact->street = "";
        $contact->city = "";
        $contact->gmail = "";
        $contact->state = "";
        $contact->postal = "";
        $contact->country = "";
        $contact->userId = session('users')->id;
        $contact->save();

        
        $background = new background();
        $background->elem = "";
        $background->elemYear = "";
        $background->junior = "";
        $background->juniorYear = "";
        
        $background->userId = session('users')->id;
        $background->save();
        
        return redirect()->route('user-usertAlertFour');

    }

    public function userProfile2 (Request $request) {

        $profiles = profile::where('userId', session('users')->id)->first();

        if($profiles) {
            $profiles->firstname  = $request->firstname;
            $profiles->middlename = $request->middlename;
            $profiles->lastname   = $request->lastname;
            $profiles->birth      = $request->birth;
            $profiles->gender     = $request->gender;
            $profiles->selfStatus = $request->selfStatus;
            $profiles->save();
            return back()->with('success', 'Save Successfully');
        }
       
        $profile = new profile();
        $profile->profile    = "";
        $profile->firstname  = $request->firstname;
        $profile->middlename = $request->middlename;
        $profile->lastname   = $request->lastname;
        $profile->birth      = $request->birth;
        $profile->gender     = $request->gender;
        $profile->selfStatus = $request->selfStatus;
        $profile->userId = session('users')->id;
        $profile->save();
        
        return back()->with('success', 'Data has been saved.');

    }

    public function userContact (Request $request) {

        $request->validate([
            'gmail' => [
                'required',
                Rule::unique('contacts', 'gmail')->where('userId', session('users')->id),
            ],
            'street' => 'required',
            'city' => 'required',
            'state' => 'required',
            'postal' => 'required',
            'country' => 'required',
        ]);

        
        $contacts = contact::where('userId', session('users')->id)->first();
        if($contacts) {
            $contacts->gmail = $request->gmail;
            $contacts->street = $request->street;
            $contacts->city = $request->city;
            $contacts->gmail = $request->gmail;
            $contacts->state = $request->state;
            $contacts->postal = $request->postal;
            $contacts->country = $request->country;
            $contacts->save();
            return back()->with('success', 'Updated Successfully');
        }

        $contact = new contact();
        $contact->gmail = $request->gmail;
        $contact->street = $request->street;
        $contact->city = $request->city;
        $contact->gmail = $request->gmail;
        $contact->state = $request->state;
        $contact->postal = $request->postal;
        $contact->country = $request->country;
        $contact->userId = session('users')->id;
        $contact->save();
        return back()->with('success', 'Save Successfully');




    }

    public function userAskTwo (Request $request) {
        $request->validate([
            'strand' => 'required',
            'year' => 'required',
            'proceed' => 'required',
        ]);

        $ask = ask::where('userId', session('users')->id)->first();
        $ask->strand = $request->strand;
        $ask->year = $request->year;
        $ask->proceed = $request->proceed;

        if($request->proceed == "no") {
            $ask->collegeName = "";
            $ask->related = "";
            
        } else {
            $ask->collegeName = $request->collegeName;
            $ask->related = $request->related;
            
        }

        $ask->save();
        return back()->with('success', 'Save Successfully');

    }


    public function userBack (Request $request) {

        $request->validate([
            'elem' => 'required',
            'elemYear' => 'required',
            'junior' => 'required',
            'juniorYear' => 'required',
        ]);

        
        $backgrounds = background::where('userId', session('users')->id)->first();
        if($backgrounds) {
            $backgrounds->elem = $request->elem;
            $backgrounds->elemYear = $request->elemYear;
            $backgrounds->junior = $request->junior;
            $backgrounds->juniorYear = $request->juniorYear;
            $backgrounds->save();
            return back()->with('success', 'Save Successfully');
        }

        $background = new background();
        $background->elem = $request->elem;
        $background->elemYear = $request->elemYear;
        $background->junior = $request->junior;
        $background->juniorYear = $request->juniorYear;
        
        $background->userId = session('users')->id;
        $background->save();
        return back()->with('success', 'Save Successfully');
        
    }


    public function userAccount (Request $request) {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
            'repeatPassword' => [
                'required',
                Rule::in([$request->input('password')]), // Check if repeatPassword matches password
            ],
        ]);

        
        $users = users::where('id', session('users')->id)->first();
        $users->username = $request->username;
        $users->password = Hash::make($request->password);
        $users->save();
        return back()->with('success', 'Change password successfully');

    }


    public function uploadProfile(Request $request)
    {
        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);
    
        // Store the uploaded image in the 'public/photos' directory
        $imagePath = $request->file('photo')->store('public/photos');
    
        // Retrieve the user's profile based on the user's ID in the session
        $profile = Profile::where('userId', session('users')->id)->first();
    
        if ($profile !== null) {
            // Get the file name with extension from the full image path
            $imageNameWithExtension = pathinfo($imagePath, PATHINFO_BASENAME);
    
            // Update the 'photo' (or 'profile') field with the file name and extension
            $profile->profile = $imageNameWithExtension;
            $profile->save();
    
            // Optionally, you can delete the old profile photo if needed
            // Storage::delete('public/photos/' . $profile->profile);
    
            return back()->with('success', 'Change password successfully');
        }
    }


    public function userCourse (Request $request) {
        $request->validate([
            'course' => 'required',
        ]);

        
        $course = course::where('userId', session('users')->id)->first();

        if ($course) {

            $course->asnwer = $request->answer;
            $course->course = $request->course;
            
            $course->userId = session('users')->id;
            $course->save();
            return redirect()->route('user-userHomeMain');

        } else {
            
            $courses = new course();
            $courses->asnwer = $request->answer;
            $courses->course = $request->course;
            $courses->userId = session('users')->id;
            $courses->save();
            
            return redirect()->route('user-userHomeMain');

        }

    
    }

}
