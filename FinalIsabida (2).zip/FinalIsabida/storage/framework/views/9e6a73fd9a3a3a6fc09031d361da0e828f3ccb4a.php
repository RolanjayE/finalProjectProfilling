<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strand Profiles</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/profile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/strandProfile.css')); ?>">
</head>
<body>

    <div class="profile">
        <div class="profile-bg">
        </div>

        <div class="profileWrapper1">
                <div class="twoHead mb-4">
                   <a href="<?php echo e(route('admin-adminHome')); ?>" class="btn btn-primary btn-sm mt-2"><i class="fa-solid fa-backward"></i></a>
                </div>

            <div class="profile-head">
                <div class="headerP">
                    <input type="search" name="search" id="searchInput" placeholder="Search Name or Year">
                </div>
                <div class="headerSelect">
                    <label for="">From</label>
                    <select name="yearFrom" id="yearSelect"></select>
                    <label for="">To</label>
                    <select name="yearTo" id="yearSelect2"></select>
                </div>
            </div>

            <p class="pp">@ <?php echo e($strand->strand); ?></p>
            <div class="profile-content">

            <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cBox">
                    <div class="img">
                        <?php if($profile->profile != ""): ?>
                                <img id="profileImage" class="img5 mt-4" src="<?php echo e(asset('storage/photos/' . $profile->profile)); ?>" alt="Profile Photo">
                            <?php else: ?>
                                <img class="img5 mt-4" id="profileImage" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                            <?php endif; ?>
                    </div>
                    <div class="info">
                        <p class="p5"><span>@</span> <?php echo e($profile->firstname); ?> <?php echo e($profile->lastname); ?></p>
                        <p class="p5 year"><?php echo e($profile->year); ?></p>
                        <a href="<?php echo e(route('admin-adminPerson', ['id' =>  $profile->userId ])); ?>" class="btn btn-success btn-sm mt-2">View Profiles</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               
                <!-- Add more cBox elements with unique identifiers as needed -->
            </div>

        </div>
    </div>

   

<script>
// Function to filter based on search input and selected year range
function filterProfiles() {
    const searchInput = document.getElementById("searchInput").value.toLowerCase();
    const yearFrom = parseInt(document.getElementById("yearSelect").value);
    const yearTo = parseInt(document.getElementById("yearSelect2").value);
    const cBoxes = document.querySelectorAll(".cBox");

    cBoxes.forEach(cBox => {
        const name = cBox.querySelector(".p5").textContent.toLowerCase();
        const year = parseInt(cBox.querySelector(".year").textContent);

        const nameMatch = name.includes(searchInput);
        const yearMatch = (year >= yearFrom && year <= yearTo);

        if (nameMatch && yearMatch) {
            cBox.style.display = "flex"; // Show matching element
        } else {
            cBox.style.display = "none";  // Hide non-matching element
        }
    });
}

// Attach the filterProfiles function to the input's "input" event and select elements' "change" event
document.getElementById("searchInput").addEventListener("input", filterProfiles);
document.getElementById("yearSelect").addEventListener("change", filterProfiles);
document.getElementById("yearSelect2").addEventListener("change", filterProfiles);

// Populate the year select elements with options from 2017 to the current year
const currentYear = new Date().getFullYear();
const yearSelect = document.getElementById("yearSelect");
const yearSelect2 = document.getElementById("yearSelect2");

for (let year = 2017; year <= currentYear; year++) {
    const option = document.createElement("option");
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
}

// Populate yearSelect2 with options from the current year to 2017
for (let year = currentYear; year >= 2017; year--) {
    const option = document.createElement("option");
    option.value = year;
    option.textContent = year;
    yearSelect2.appendChild(option);
}
</script>


    
</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/admin/admin-strandProfile.blade.php ENDPATH**/ ?>