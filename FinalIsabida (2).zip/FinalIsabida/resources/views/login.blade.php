<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/login.css') }}">
</head>
<body>
    
    <div class="login">
        <div class="loginWrapper">
        @if(session('save'))<div class="alert alert-success">{{ session('save') }}</div>@endif
            <form action="{{ route('loginValidate') }}" method="post">
                @csrf
                <div class="logn-head">
                    <img class="img5 mb-3" src="{{ asset('image/gcclogo.png') }}" alt="">
                  <div class="gwapoCon">
                    <p class="gwapoIsabida">Welcome Students Of GCC</p>
                    <p class="cuteUIsabida">SHS Alumni Profiling System</p>
                </div>
                  </div>
               <div class="fomrbox">
                    <label for="">Username</label>
                    <input type="text" name="username">
                    <p style="color: red" >@error('username'){{ $message }}@enderror</p>
               </div>
               <div class="fomrbox">
                    <label for="">Password</label>
                    <input type="Password" name="password">
                    <p style="color: red" >@error('password'){{ $message }}@enderror</p>

                    <!-- <div class="newb mb-2"><a href="{{ route('forget') }}">Forget Password ?</a></div> -->
                    <button style="float: right; width: 100%;" type="submit" class="btn btn-primary btn-sm mt-3">Login</button>
               </div>
            </form>
        </div>
    </div>

</body>
</html>