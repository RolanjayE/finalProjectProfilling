<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('user/home.css') }}">
    <link rel="stylesheet" href="{{ asset('user/main.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <div class="home-con">
        <x-userHeader />
        <div class="bg">
        </div>

        <div class="home-wrapper">
            <div class="home-left">
                @if($profiles->profile != "")
                    <img id="profileImage" class="img4 mb-2" src="{{ asset('storage/photos/' . $profiles->profile) }}" alt="Profile Photo">
                @else
                    <img class="img4 mb-2" id="profileImage" src="{{ asset('image/profile.png') }}" alt="">
                @endif
                    <div class="user-data">
                    <p class="p4">{{ $profiles->firstname }} {{ $profiles->lastname }}</p>
                    <p class="p1">@ GINGOOG CITY COLLEGES <br> @ {{ $strand->strand }} <br> @ {{ $ask->year }}</p>
                    <a href="{{ route('user-home') }}" class="btn btn-success btn-sm mt-2"><i class="fa-solid fa-user mt-2"></i> Information</a>
                </div>
            </div>
            <div class="home-right">
                <div class="head-search">
                    
                    <p>@ {{ $strand->strand }}</p>
                    <input type="search" name="" id="searchInput" placeholder="Search name">
                </div>


                <div class="box-content">
                    @foreach ($profileSpecials as $profileSpecial)
                    <div class="cBox">
                        <div class="img">
                        @if($profileSpecial->profile != "")
                            <img id="profileImage" class="img5 mb-2" src="{{ asset('storage/photos/' . $profileSpecial->profile) }}" alt="Profile Photo">
                        @else
                            <img class="img5 mb-2" id="profileImage" src="{{ asset('image/profile.png') }}" alt="">
                        @endif
                        </div>
                        <div class="info">
                            <p class="p5">{{ $profileSpecial->firstname }} {{ $profileSpecial->middlename }} {{ $profileSpecial->lastname }}</p>
                        </div>
                    </div> 
                    @endforeach
                </div>
                
            </div>
        </div>

        
    </div>



    <script>
        // Get references to the search input and all cBox elements
        const searchInput = document.getElementById('searchInput');
        const cBoxElements = document.querySelectorAll('.cBox');

        // Add an event listener to the search input to filter and display elements
        searchInput.addEventListener('input', () => {
            const searchValue = searchInput.value.toLowerCase();
            
            cBoxElements.forEach((cBoxElement) => {
                const pElement = cBoxElement.querySelector('.p5');
                if (pElement) {
                    const textContent = pElement.textContent.toLowerCase();
                    const shouldDisplay = textContent.includes(searchValue);
                    cBoxElement.style.display = shouldDisplay ? 'flex' : 'none';
                }
            });
        });
    </script>

    
</body>
</html>