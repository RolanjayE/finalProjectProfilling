<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/adminhome.css')); ?>">
   
</head>
<body>


    <div class="admin-home">
        <div class="admin-header">
            <div class="admin-header-right">
                <a href="<?php echo e(route('logout')); ?>" type="submit" class="btn btn-danger btn-sm mt-3"> <i class="fa-solid fa-right-from-bracket"></i> </a>
                    
            </div>
            <div class="menuAdmin">
                <li><a style="color: green;" href="<?php echo e(route('admin-adminHome')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('admin-adminUser')); ?>">Users</a></li>
                <li><a href="<?php echo e(route('admin-adminStrand')); ?>">Strand</a></li>
                <li><a href="<?php echo e(route('admin-profile')); ?>">Profile</a></li>
                <li><a href="<?php echo e(route('admin-adminSettings')); ?>">Settings</a></li>
                <li><a href="<?php echo e(route('admin-question')); ?>"><span>Reports</span></a></li>
            </div>
        </div>


        <div class="admin-mian">
            <div class="backImg">
                <img class="img6" src="<?php echo e(asset('image/grad2.jpg')); ?>" alt="">
            </div>
            <div class="wrapper2 adminMainContainer">
                <div class="adminLeft">
                <?php $__currentLoopData = $strandCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strandCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($strandCount->strand != 'TEMP'): ?>
                        <div class="adminLeftBox">
                            <a href="<?php echo e(route('admin-strandProfiles', ['id' => $strandCount->id ])); ?>"><?php echo e($strandCount->strand); ?></a><br>
                            <i class="fa-solid fa-user mt-2"></i> <span><?php echo e($strandCount->user_count); ?></span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="admin-right">

                    <div class="box-content">

                    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="cBox">
                            <div class="img">
                            <?php if($profile->profile != ""): ?>
                                <img id="profileImage" class="img5 mb-3" src="<?php echo e(asset('storage/photos/' . $profile->profile)); ?>" alt="Profile Photo">
                            <?php else: ?>
                                <img class="img5 mb-2" id="profileImage" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                            <?php endif; ?>
                            </div>
                            <div class="info">
                                <p class="p5 mt-3"><?php echo e($profile->firstname); ?> <?php echo e($profile->lastname); ?></p>
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                        
                        
                    </div>
                    
                    <a href="<?php echo e(route('admin-profile')); ?>" style="float: right; width: 100%;" type="submit" class="btn btn-success btn-sm mt-3">Visit Profiles </a>
                    
                </div>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/admin/admin-home.blade.php ENDPATH**/ ?>