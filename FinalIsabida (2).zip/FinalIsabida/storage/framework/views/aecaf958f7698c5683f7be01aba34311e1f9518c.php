<div class="home-header">
    <div class="header-right">
        <i id="ShowHideBtn" class="fa-solid fa-chevron-down headIcon"></i>
        <img class="img3" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
        <div class="show-box" style="display: none;">
            <li><a href="<?php echo e(route('user-userHomeMain')); ?>"><i class="fa-solid fa-user"></i> Profile</a></li>
            <li><a href="<?php echo e(route('user-home')); ?>"><i class="fa-solid fa-user"></i> Info</a></li>
            <li><a href="<?php echo e(route('logout')); ?>"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </div>
    </div>
</div>


<script>
    const toggleButton = document.getElementById('ShowHideBtn');
    const showBox = document.querySelector('.show-box');

    toggleButton.addEventListener('click', () => {
        if (showBox.style.display === 'none' || showBox.style.display === '') {
            showBox.style.display = 'block';
        } else {
            showBox.style.display = 'none';
        }
    });
</script><?php /**PATH C:\FinalIsabida\resources\views/components/user-header.blade.php ENDPATH**/ ?>