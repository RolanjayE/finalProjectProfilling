<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('user/home.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    

    <div class="home-con">

       <x-userHeader />

        <div class="wrapper">
            <div class="home">

                <div class="home-left">
                    <div class="profile">
                        <div class="pic">
                                @if($profiles->profile != "")
                                    <img class="img2" src="{{ asset('storage/photos/' . $profiles->profile) }}" alt="Profile Photo">
                                @else
                                    <img class="img2" src="{{ asset('image/profile.png') }}" alt="">
                                @endif
                        </div>
                        <div class="info">
                            <a class="home-a" href="{{ route('user-userHomeMain') }}"> {{  $profiles->firstname  }} {{  $profiles->lastname  }}</a>
                            <p class="p1">@GCC STUDENT</p>
                        </div>
                    </div>
                    <i id="tog" class="fa-solid fa-square-caret-down menuIcon"></i>
                    <div class="home-menu show">
                        <li><a href="{{ route('user-userHomeMain') }}"><i class="fa-solid fa-user"></i> Profile</a></li>
                        <li><a href="#personal"><i class="fa-solid fa-user"></i> Personal</a></li>
                        <li><a href="#contact"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                        <li><a href="#Background"><i class="fa-solid fa-graduation-cap"></i> Background</a></li>
                        <li><a href="#Question"><i class="fa-solid fa-circle-question"></i> Question</a></li>
                        <li><a href="#account"><i class="fa-solid fa-lock-open"></i></i> Account</a></li>
                    </div>
                    
                </div>

                <div class="home-right">
                    <div class="home-right-con">
                        <p class="p2">Profile</p>
                        
                        @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                        <div class="form-profile" id="personal">

                            <div class="conProfile">
                                @if($profiles->profile != "")
                                    <img id="profileImage" class="img1" src="{{ asset('storage/photos/' . $profiles->profile) }}" alt="Profile Photo">
                                @else
                                    <img class="img1 mb-2" id="profileImage" src="{{ asset('image/profile.png') }}" alt="">
                                @endif
                                <form method="POST" action="{{ route('user-uploadProfile') }}" enctype="multipart/form-data">
                                    @csrf
                                    <input style="width: 114px;" type="file" id="imageInput" accept="image/*" onchange="updateImage()" name="photo">
                                    <br>
                                    <button type="submit" class="btn btn-primary btn-sm mt-2"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                                </form>
                            </div>

                            <form action="{{ route('user-userProfile2') }}" method="post">
                                @csrf
                                <p class="warning">* You can change your personal information here!</p>
                             
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">First name</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="{{ $profiles->firstname }}" name="firstname">
                                    </div>
                                    <div class="box">
                                        <label for="">Last name</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="{{ $profiles->lastname }}" name="lastname">
                                    </div>
                                </div>
                                <div class="single-box">
                                    <label for="">Middle name</label><br>
                                    <input style="text-transform: uppercase;" type="text" value="{{ $profiles->middlename }}" name="middlename">
                                </div>
                                <div class="single-box">
                                    <label for="">Date of birth</label><br>
                                    <input style="text-transform: uppercase;" type="date" value="{{ $profiles->birth }}" name="birth">
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Gender</label><br>
                                        <select name="gender" id="">
                                            <option value="{{ $profiles->gender }}">{{ $profiles->gender }}</option>
                                            <option value="">Male</option>
                                            <option value="">Female</option>
                                        </select>
                                    </div>
                                    <div class="box">
                                        <label for="">Status</label><br>
                                        <select name="selfStatus" id="">
                                            <option value="{{ $profiles->selfStatus }}">{{ $profiles->selfStatus }}</option>
                                            <option value="">Single</option>
                                            <option value="">Married</option>
                                        </select>
                                    </div>
                                </div>
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>

                    </div>

                    <div class="contact" id="contact">
                        <p class="p2">Contact</p>
                        <div class="form-contact">
                            <form action="{{ route('user-userContact') }}" method="post">
                                @csrf
                                <div class="single-box">
                                    <label for="">Gmail</label><br>
                                    <input style="text-transform: uppercase;" type="gmail" name="gmail" value="{{ $contact->gmail }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('gmail'){{ $message }}@enderror</p>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Street Address</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="street" value="{{ $contact->street }}">
                                        <p style="color: red" id="proceedErrorMessage">@error('street'){{ $message }}@enderror</p>
                                    </div>
                                    <div class="box">
                                        <label for="">City</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="city" value="{{ $contact->city }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('city'){{ $message }}@enderror</p>
                                    </div>
                                    <div class="box">
                                        <label for="">State</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="state" value="{{ $contact->state }}">
                                        <p style="color: red" id="proceedErrorMessage">@error('state'){{ $message }}@enderror</p>
                                    </div>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Postal Code</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="postal" value="{{ $contact->postal }}">
                                        <p style="color: red" id="proceedErrorMessage">@error('postal'){{ $message }}@enderror</p>
                                    </div>
                                    <div class="box">
                                        <label for="">Country</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="country" value="{{ $contact->country }}">
                                        <p style="color: red" id="proceedErrorMessage">@error('country'){{ $message }}@enderror</p>
                                    </div>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact"  id="Background">
                        <p class="p2">Background</p>
                        <div class="form-contact">
                            <form action="{{ route('user-userBack') }}" method="post">
                                @csrf
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Elementary Education</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="elem" value="{{ $background->elem }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('elem'){{ $message }}@enderror</p>
                                    </div>
                                    <div class="box">
                                        <label for="">Year Graduate</label><br>
                                        <input style="text-transform: uppercase;" type="number" name="elemYear" value="{{ $background->elemYear }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('elemYear'){{ $message }}@enderror</p>
                                    </div>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Junior High School</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="junior" value="{{ $background->junior }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('junior'){{ $message }}@enderror</p>
                                    </div>
                                    <div class="box">
                                        <label for="">Year Graduate</label><br>
                                        <input style="text-transform: uppercase;" type="number" name="juniorYear" value="{{ $background->juniorYear }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('juniorYear'){{ $message }}@enderror</p>
                                    </div>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact" id="Question">
                        <p class="p2">Question</p>
                        <div class="form-contact">
                            <form action="{{ route('user-userAskTwo') }}" method="post">
                                @csrf
                                <div class="single-box">
                                    <label for="">Strand </label><br>
                                    <select name="strand" id="">
                                        <option value="{{ $userStrand->id }}">{{ $userStrand->strand }}</option>
                                        @foreach($strands as $strand)
                                            <option value="{{ $strand->id }}"> {{ $strand->strand }}</option>
                                        @endforeach
                                    </select>
                                    <p style="color: red" >@error('strand'){{ $message }}@enderror</p>
                                </div>
                                <div class="single-box">
                                    <label for="">Year Graduate</label><br>
                                    <select name="year" id="yearSelect">
                                        <option value="{{ $ask->year }}">{{ $ask->year }}</option>
                                        <option>2021</option>
                                        <option>2021</option>
                                        <option>2021</option>
                                    </select>
                                    <p style="color: red" >@error('year'){{ $message }}@enderror</p>
                                    
                                </div>

                                <div class="single-box">
                                    <label for="">Did you proceed to college ?</label><br>
                                    <select name="proceed" id="proceedSelect">
                                        <option value="{{ $ask->proceed }}">{{ $ask->proceed }}</option>
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
                                    </select>
                                    <p style="color: red" id="proceedErrorMessage">@error('proceed'){{ $message }}@enderror</p>
                                </div>

                                <div class="showThis" id="collegeInfo">
                                    <div class="single-box">
                                        <label for="">Name of School</label><br>
                                        <input name="collegeName" style="text-transform: uppercase;" type="text" value="{{ $ask->collegeName }}">
                                        <p style="color: red" id="collegeNameErrorMessage">@error('collegeName'){{ $message }}@enderror</p>
                                    </div>

                                    <div class="single-box">
                                        <label for="">Is your STRAND related to a course in college?</label><br>
                                        <select name="related" id="relatedSelect">
                                            <option value="{{ $ask->related }}">{{ $ask->related }}</option>
                                            <option value="yes">Yes</option>
                                            <option value="no">No</option>
                                        </select>
                                        <p style="color: red" id="relatedErrorMessage">@error('related'){{ $message }}@enderror</p>
                                    </div>
                                </div>
                    
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm mt-2"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact" id="account">
                        <p class="p2">My Account</p>
                        <div class="form-contact">
                            <form action="{{ 'user-userAccount' }}" method="post">
                                @csrf
                                <div class="single-box">
                                    <label for="">Username</label><br>
                                    <input style="text-transform: uppercase;" type="text" value="{{ $users->username }}" name="username">
                                    <p style="color: red" id="proceedErrorMessage">@error('username'){{ $message }}@enderror</p>
                                </div>

                                <div class="single-box">
                                    <label for="">New Password</label><br>
                                    <input style="text-transform: uppercase;" type="password" name="password" value="{{ old('password') }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('password'){{ $message }}@enderror</p>
                                </div>

                                <div class="single-box">
                                    <label for="">Repeat Password</label><br>
                                    <input style="text-transform: uppercase;" type="password" name="repeatPassword" value="{{ old('repeatPassword') }}">
                                    <p style="color: red" id="proceedErrorMessage">@error('repeatPassword'){{ $message }}@enderror</p>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>



                </div>

            </div>
        </div>
    </div>

    
<script>
    const tog = document.getElementById('tog');
    const show = document.querySelector('.show');

    tog.addEventListener('click', () => {
        if (show.style.display === 'none' || show.style.display === '') {
            show.style.display = 'block';
        } else {
            show.style.display = 'none';
        }
    });
</script>

<script>
    // Get a reference to the input element
    const inputElement = document.getElementById('uppercaseInput');

    // Add an event listener to the input element
    inputElement.addEventListener('input', function() {
        // Convert the input value to uppercase
        this.value = this.value.toUpperCase();
    });
</script>


<script>
        // Function to update the image when a new file is selected
        function updateImage() {
            const imageInput = document.getElementById('imageInput');
            const profileImage = document.getElementById('profileImage');
            
            if (imageInput.files && imageInput.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    profileImage.src = e.target.result;
                }

                reader.readAsDataURL(imageInput.files[0]);
            }
        }
    </script>
    <script>
// Get a reference to the select element
const yearSelect = document.getElementById('yearSelect');

// Get the current year
const currentYear = new Date().getFullYear();

// Generate options for years starting from 2017 to the current year
for (let year = 2017; year <= currentYear; year++) {
    const option = document.createElement('option');
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
}

// Select the default value if needed
// yearSelect.value = "{{ $ask->year }}"; // Uncomment this line if you want to set the default value
</script>


   
</body>
</html>