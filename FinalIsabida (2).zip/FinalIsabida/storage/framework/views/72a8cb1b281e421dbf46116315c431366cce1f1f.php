<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/home.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    

    <div class="home-con">

       <?php if (isset($component)) { $__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c = $component; } ?>
<?php $component = App\View\Components\UserHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('userHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\UserHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c)): ?>
<?php $component = $__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c; ?>
<?php unset($__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c); ?>
<?php endif; ?>

        <div class="wrapper">
            <div class="home">

                <div class="home-left">
                    <div class="profile">
                        <div class="pic">
                                <?php if($profiles->profile != ""): ?>
                                    <img class="img2" src="<?php echo e(asset('storage/photos/' . $profiles->profile)); ?>" alt="Profile Photo">
                                <?php else: ?>
                                    <img class="img2" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                                <?php endif; ?>
                        </div>
                        <div class="info">
                            <a class="home-a" href="<?php echo e(route('user-userHomeMain')); ?>"> <?php echo e($profiles->firstname); ?> <?php echo e($profiles->lastname); ?></a>
                            <p class="p1">@GCC STUDENT</p>
                        </div>
                    </div>
                    <i id="tog" class="fa-solid fa-square-caret-down menuIcon"></i>
                    <div class="home-menu show">
                        <li><a href="<?php echo e(route('user-userHomeMain')); ?>"><i class="fa-solid fa-user"></i> Profile</a></li>
                        <li><a href="#personal"><i class="fa-solid fa-user"></i> Personal</a></li>
                        <li><a href="#contact"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                        <li><a href="#Background"><i class="fa-solid fa-graduation-cap"></i> Background</a></li>
                        <li><a href="#Question"><i class="fa-solid fa-circle-question"></i> Question</a></li>
                        <li><a href="#account"><i class="fa-solid fa-lock-open"></i></i> Account</a></li>
                    </div>
                    
                </div>

                <div class="home-right">
                    <div class="home-right-con">
                        <p class="p2">Profile</p>
                        
                        <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
                        <div class="form-profile" id="personal">

                            <div class="conProfile">
                                <?php if($profiles->profile != ""): ?>
                                    <img id="profileImage" class="img1" src="<?php echo e(asset('storage/photos/' . $profiles->profile)); ?>" alt="Profile Photo">
                                <?php else: ?>
                                    <img class="img1 mb-2" id="profileImage" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('user-uploadProfile')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input style="width: 114px;" type="file" id="imageInput" accept="image/*" onchange="updateImage()" name="photo">
                                    <br>
                                    <button type="submit" class="btn btn-primary btn-sm mt-2"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                                </form>
                            </div>

                            <form action="<?php echo e(route('user-userProfile2')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <p class="warning">* You can change your personal information here!</p>
                             
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">First name</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($profiles->firstname); ?>" name="firstname">
                                    </div>
                                    <div class="box">
                                        <label for="">Last name</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($profiles->lastname); ?>" name="lastname">
                                    </div>
                                </div>
                                <div class="single-box">
                                    <label for="">Middle name</label><br>
                                    <input style="text-transform: uppercase;" type="text" value="<?php echo e($profiles->middlename); ?>" name="middlename">
                                </div>
                                <div class="single-box">
                                    <label for="">Date of birth</label><br>
                                    <input style="text-transform: uppercase;" type="date" value="<?php echo e($profiles->birth); ?>" name="birth">
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Gender</label><br>
                                        <select name="gender" id="">
                                            <option value="<?php echo e($profiles->gender); ?>"><?php echo e($profiles->gender); ?></option>
                                            <option value="">Male</option>
                                            <option value="">Female</option>
                                        </select>
                                    </div>
                                    <div class="box">
                                        <label for="">Status</label><br>
                                        <select name="selfStatus" id="">
                                            <option value="<?php echo e($profiles->selfStatus); ?>"><?php echo e($profiles->selfStatus); ?></option>
                                            <option value="">Single</option>
                                            <option value="">Married</option>
                                        </select>
                                    </div>
                                </div>
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>

                    </div>

                    <div class="contact" id="contact">
                        <p class="p2">Contact</p>
                        <div class="form-contact">
                            <form action="<?php echo e(route('user-userContact')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="single-box">
                                    <label for="">Gmail</label><br>
                                    <input style="text-transform: uppercase;" type="gmail" name="gmail" value="<?php echo e($contact->gmail); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['gmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Street Address</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="street" value="<?php echo e($contact->street); ?>">
                                        <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">City</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="city" value="<?php echo e($contact->city); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">State</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="state" value="<?php echo e($contact->state); ?>">
                                        <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Postal Code</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="postal" value="<?php echo e($contact->postal); ?>">
                                        <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">Country</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="country" value="<?php echo e($contact->country); ?>">
                                        <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact"  id="Background">
                        <p class="p2">Background</p>
                        <div class="form-contact">
                            <form action="<?php echo e(route('user-userBack')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Elementary Education</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="elem" value="<?php echo e($background->elem); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['elem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">Year Graduate</label><br>
                                        <input style="text-transform: uppercase;" type="number" name="elemYear" value="<?php echo e($background->elemYear); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['elemYear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Junior High School</label><br>
                                        <input style="text-transform: uppercase;" type="text" name="junior" value="<?php echo e($background->junior); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['junior'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">Year Graduate</label><br>
                                        <input style="text-transform: uppercase;" type="number" name="juniorYear" value="<?php echo e($background->juniorYear); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['juniorYear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact" id="Question">
                        <p class="p2">Question</p>
                        <div class="form-contact">
                            <form action="<?php echo e(route('user-userAskTwo')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="single-box">
                                    <label for="">Strand </label><br>
                                    <select name="strand" id="">
                                        <option value="<?php echo e($userStrand->id); ?>"><?php echo e($userStrand->strand); ?></option>
                                        <?php $__currentLoopData = $strands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($strand->id); ?>"> <?php echo e($strand->strand); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <p style="color: red" ><?php $__errorArgs = ['strand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div class="single-box">
                                    <label for="">Year Graduate</label><br>
                                    <select name="year" id="yearSelect">
                                        <option value="<?php echo e($ask->year); ?>"><?php echo e($ask->year); ?></option>
                                        <option>2021</option>
                                        <option>2021</option>
                                        <option>2021</option>
                                    </select>
                                    <p style="color: red" ><?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    
                                </div>

                                <div class="single-box">
                                    <label for="">Did you proceed to college ?</label><br>
                                    <select name="proceed" id="proceedSelect">
                                        <option value="<?php echo e($ask->proceed); ?>"><?php echo e($ask->proceed); ?></option>
                                        <option value="yes">Yes</option>
                                        <option value="no">No</option>
                                    </select>
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['proceed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>

                                <div class="showThis" id="collegeInfo">
                                    <div class="single-box">
                                        <label for="">Name of School</label><br>
                                        <input name="collegeName" style="text-transform: uppercase;" type="text" value="<?php echo e($ask->collegeName); ?>">
                                        <p style="color: red" id="collegeNameErrorMessage"><?php $__errorArgs = ['collegeName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>

                                    <div class="single-box">
                                        <label for="">Is your STRAND related to a course in college?</label><br>
                                        <select name="related" id="relatedSelect">
                                            <option value="<?php echo e($ask->related); ?>"><?php echo e($ask->related); ?></option>
                                            <option value="yes">Yes</option>
                                            <option value="no">No</option>
                                        </select>
                                        <p style="color: red" id="relatedErrorMessage"><?php $__errorArgs = ['related'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                </div>
                    
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm mt-2"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact" id="account">
                        <p class="p2">My Account</p>
                        <div class="form-contact">
                            <form action="<?php echo e('user-userAccount'); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="single-box">
                                    <label for="">Username</label><br>
                                    <input style="text-transform: uppercase;" type="text" value="<?php echo e($users->username); ?>" name="username">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>

                                <div class="single-box">
                                    <label for="">New Password</label><br>
                                    <input style="text-transform: uppercase;" type="password" name="password" value="<?php echo e(old('password')); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>

                                <div class="single-box">
                                    <label for="">Repeat Password</label><br>
                                    <input style="text-transform: uppercase;" type="password" name="repeatPassword" value="<?php echo e(old('repeatPassword')); ?>">
                                    <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['repeatPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm"> <i class="fa-solid fa-user mt-2"></i> Save Changes</button>
                            </form>
                        </div>
                    </div>



                </div>

            </div>
        </div>
    </div>

    
<script>
    const tog = document.getElementById('tog');
    const show = document.querySelector('.show');

    tog.addEventListener('click', () => {
        if (show.style.display === 'none' || show.style.display === '') {
            show.style.display = 'block';
        } else {
            show.style.display = 'none';
        }
    });
</script>

<script>
    // Get a reference to the input element
    const inputElement = document.getElementById('uppercaseInput');

    // Add an event listener to the input element
    inputElement.addEventListener('input', function() {
        // Convert the input value to uppercase
        this.value = this.value.toUpperCase();
    });
</script>


<script>
        // Function to update the image when a new file is selected
        function updateImage() {
            const imageInput = document.getElementById('imageInput');
            const profileImage = document.getElementById('profileImage');
            
            if (imageInput.files && imageInput.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    profileImage.src = e.target.result;
                }

                reader.readAsDataURL(imageInput.files[0]);
            }
        }
    </script>
    <script>
// Get a reference to the select element
const yearSelect = document.getElementById('yearSelect');

// Get the current year
const currentYear = new Date().getFullYear();

// Generate options for years starting from 2017 to the current year
for (let year = 2017; year <= currentYear; year++) {
    const option = document.createElement('option');
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
}

// Select the default value if needed
// yearSelect.value = "<?php echo e($ask->year); ?>"; // Uncomment this line if you want to set the default value
</script>


   
</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/user/user-home.blade.php ENDPATH**/ ?>